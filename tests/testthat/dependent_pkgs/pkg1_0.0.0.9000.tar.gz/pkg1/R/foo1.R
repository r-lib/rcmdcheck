#' foo1 description
#'
#' foo1
#' @export
foo1 <- function() {1}